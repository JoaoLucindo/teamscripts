﻿$GroupName = "callcentermanagers" ##grupo de segurança para exceçao do privilégio de criação de grupo
$AllowGroupCreation = "False"

Connect-AzureAD

$settingsObjectID = (Get-AzureADDirectorySetting | Where-object -Property Displayname -Value "Group.Unified" -EQ).id  ## verifica se já existe um configuração para o Group Unified
if(!$settingsObjectID) ##se nao tiver configuração
{ #cria configuração Group Unified

	$template = Get-AzureADDirectorySettingTemplate | Where-object {$_.displayname -eq "group.unified"} ## Copia um template de configuração
    $settingsCopy = $template.CreateDirectorySetting() ## atribui numa variavel as configuraçoes de criacao de grupos
    New-AzureADDirectorySetting -DirectorySetting $settingsCopy ## cria a configuração que até entao nao existia utilizando as definicoes da variavel $settingsCopy
    $settingsObjectID = (Get-AzureADDirectorySetting | Where-object -Property Displayname -Value "Group.Unified" -EQ).id  ##obtem o ID dessa configuracao (Group Unified) do Azure AD
}

$settingsCopy = Get-AzureADDirectorySetting -Id $settingsObjectID ## atribui numa variavel as configuraçoes de criacao de grupos
$settingsCopy["EnableGroupCreation"] = $AllowGroupCreation ##atribui como False para a criação de grupos

if($GroupName) ## se for definido um grupo de segurança para exceção
{
	$settingsCopy["GroupCreationAllowedGroupId"] = (Get-AzureADGroup -SearchString $GroupName).objectid #obtem o ID do grupoS
}
 else {
$settingsCopy["GroupCreationAllowedGroupId"] = $GroupName
}
Set-AzureADDirectorySetting -Id $settingsObjectID -DirectorySetting $settingsCopy  #seta a configuracao para o grupo

(Get-AzureADDirectorySetting -Id $settingsObjectID).Values #retorna a nova configuração