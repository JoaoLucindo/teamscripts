﻿#Passo 0
#Criar o grupo template com as configuracoes desejadas e copiar o nome dele, vou chama-lo de <grupotemplatenome> 
# 
#Passo 1
#Instalar Módulo Power Shell Graph API:  
Install-Module Microsoft.Graph
 
#Passo 2
#Conectar na Graph API:
 
Connect-Graph -Scopes "User.Read","User.ReadWrite.All","Directory.ReadWrite.All","Group.ReadWrite.All"
#Passo 3
#Rodar:
 
# Variaveis
$modeloEquipe = "<grupotemplatenome>" ; $idEquipe = (Get-Team -DisplayName $modeloEquipe).GroupId
$quantidadeEquipes = 5
$prefixoEquipes = "Prefixo do nome da equipe"
$descricaoEquipe = "descriçao....."
$i = 1
  
# Inicio do script
 
DO
    {
    # Construir nome e alias
    $nomeEquipe = $prefixoEquipes + " 0$i"
    $aliasEquipe = $nomeEquipe.Replace(" ","-")
    # Provisionar nova equipe
    Write-Host "Criando equipe: $nomeEquipe"
    Copy-MgTeam -TeamId $idEquipe -DisplayName $nomeEquipe -MailNickname $aliasEquipe -Description $descricaoEquipe -PartsToClone "apps,tabs,settings,channels,members" -Visibility Private
    $equipe = Get-Team -DisplayName $nomeEquipe | select GroupId,DisplayName,MailNickName,Visibility,Description | Export-Csv -Path C:\Temp\EquipesCriadas.csv -Append -NoTypeInformation -Encoding UTF8
    $i++
} While ($i -le $quantidadeEquipes)