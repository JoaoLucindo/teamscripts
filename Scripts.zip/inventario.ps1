﻿Connect-MicrosoftTeams


$UPN = Import-Csv C:\Users\jolucind\Desktop\userlist.csv 

$Inventario = @()

$Inventario += "sep=;"

$Inventario += "UPN;MeetingPolicy;LivePolicy;CallingPolicy;AppSetupPolicy;AppPermissonPolicy;MessagingPolicy"
  


foreach ($UPN_user in $UPN)
    {

    

    $UserPolicy = Get-CsUserPolicyAssignment  -Identity $UPN_user.UPN

    $UserMeetingPolicy =  $UserPolicy | Where-Object {$_.PolicyType -eq 'TeamsMeetingPolicy'} | Select PolicyName 

    $UserMeetingBroadcastPolicy = $UserPolicy | Where-Object {$_.PolicyType -eq 'TeamsMeetingBroadcastPolicy '} | Select PolicyName 

    $UserCallingPolicy = $UserPolicy | Where-Object {$_.PolicyType -eq 'TeamsCallingPolicy'} | Select PolicyName 

    $UserAppSetupPolicy = $UserPolicy | Where-Object {$_.PolicyType -eq 'TeamsAppSetupPolicy'} | Select PolicyName

    $UserAppPermissionPolicy = $UserPolicy | Where-Object {$_.PolicyType -eq 'TeamsAppPermissionPolicy'} | Select PolicyName

    $UserMessagingPolicy = $UserPolicy | Where-Object {$_.PolicyType -eq 'TeamsMessagingPolicy'} | Select PolicyName
    
     
    ##write-host $UPN_user.UPN "|" $UserMeetingPolicy.PolicyName "|" $UserMeetingBroadcastPolicy.PolicyName "|" $UserCallingPolicy.PolicyName "|" $UserAppSetupPolicy.PolicyName "|" $UserAppPermissionPolicy.PolicyName "|" $UserMessagingPolicy.PolicyName
    
    $Inventario += $UPN_user.UPN + ";" + $UserMeetingPolicy.PolicyName+ ";" + $UserMeetingBroadcastPolicy.PolicyName + ";" + $UserCallingPolicy.PolicyName+ ";" +$UserAppSetupPolicy.PolicyName+ ";" + $UserAppPermissionPolicy.PolicyName+ ";" +$UserMessagingPolicy.PolicyName

    }



$Date = Get-Date -Format ddMMyyyy_HHmmss
 
$FilePath = "$Env:USERPROFILE\Desktop\Teams_Policy_Report_$Date.csv"
 
$Inventario | Add-Content -Path $FilePath  